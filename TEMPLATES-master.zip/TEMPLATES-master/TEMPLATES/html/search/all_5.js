var searchData=
[
  ['main',['main',['../_t_e_m_p_l_a_t_e_s_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'TEMPLATES.cpp']]]
];
